#include <stdio.h>

const char *message(void);

int main(int argc, char *argv[]) {
  printf("%s\n", message());
  return 0;
}
