#include <stdio.h>

void subdir1_func(void)
{
  printf("Hello %s from subdir1/func.c\n", PROG);
}
