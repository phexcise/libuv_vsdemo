int f() { return 42; }
