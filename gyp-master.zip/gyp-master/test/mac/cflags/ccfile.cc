#ifdef CFLAG
#error CFLAG should not be set
#endif

#ifndef CCFLAG
#error CCFLAG should be set
#endif
