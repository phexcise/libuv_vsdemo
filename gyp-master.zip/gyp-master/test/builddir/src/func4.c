#include <stdio.h>

void func4(void)
{
  printf("Hello from func4.c\n");
}
