#include <stdio.h>

void func5(void)
{
  printf("Hello from func5.c\n");
}
