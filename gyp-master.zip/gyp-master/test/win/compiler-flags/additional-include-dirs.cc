// Copyright (c) 2012 Google Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// No path qualification to test compiler include dir specification.
#include "header.h"

int main() {
  return 0;
}
